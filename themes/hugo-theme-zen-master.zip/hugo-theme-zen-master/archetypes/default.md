---
title: "{{ replace .TranslationBaseName "-" " " | humanize }}"
date: {{ .Date }}
lastmod: {{ .Date }}

---