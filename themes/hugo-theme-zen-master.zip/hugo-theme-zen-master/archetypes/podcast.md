---
title: "{{ replace .TranslationBaseName "-" " " | humanize }}"
date: {{ .Date }}
podcast:
    mp3:
    duration:

---