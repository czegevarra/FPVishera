module.exports = {
  arrowParens: "avoid",
  bracketSpacing: false,
  endOfLine: "lf",
  htmlWhitespaceSensitivity: "css",
  printWidth: 80,
  proseWrap: "always",
  semi: true,
  singleQuote: false,
  tabWidth: 2,
  trailingComma: "all",
  useTabs: false,
};
