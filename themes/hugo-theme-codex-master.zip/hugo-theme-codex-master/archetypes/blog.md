---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
slug: ""
description: ""
keywords: []
draft: true
tags: []
math: false
toc: false
---
